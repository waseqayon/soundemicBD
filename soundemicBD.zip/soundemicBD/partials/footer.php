
 <section class="soundemicbd-newsletter-area bg-img bg-overlay pt-50 jarallax" style="background-image: url(img/bg-img/15.jpg);">
    <div class="container">
      <div class="row align-items-center">

        <div class="col-12 col-lg-6">
          <div class="newsletter-content mb-50">
            <h2>Sign Up For Newsletter</h2>
            <h6>Subscribe to receive info on our latest podcasts</h6>
          </div>
        </div>

        <div class="col-12 col-lg-6">
          <div class="newsletter-form mb-50">
            <form action="#" method="post">
              <input type="email" name="nl-email" class="form-control" placeholder="Your Email">
              <button type="submit" class="btn">Subscribe</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>


  <footer class="footer-area section-padding-80-0">
    <div class="container">
      <div class="row">


        <div class="col-12 col-sm-6 col-lg-3">
          <div class="single-footer-widget mb-80">

            <h4 class="widget-title">About Us</h4>
            <body>
            <a href="logout.php" class="btn soundemicbd-btn m-2 ml-0 active" data-animation="fadeInUp" data-delay="500ms">Logout</a>
            </body>
            </html>

            <p></p>
            <div class="copywrite-content">
              <p>&copy; 


Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved | Build by Waseq Ayon</p>
            </div>
          </div>
        </div>


        <div class="col-12 col-sm-6 col-lg-3">
          <div class="single-footer-widget mb-80">

            <h4 class="widget-title">Categories</h4>


            <nav>
              <ul class="catagories-nav">
                <li><a href="#">Metal</a></li>
                <li><a href="#">Rock</a></li>
                <li><a href="#">Tech</a></li>
                <li><a href="#">Acoustic</a></li>
              </ul>
            </nav>
          </div>
        </div>


        <div class="col-12 col-sm-6 col-lg-3">
          <div class="single-footer-widget mb-80">

            <h4 class="widget-title">Lastest EPs</h4>


            <div class="single-latest-EPs">
              <p class="EPs-date">December 9, 2018</p>
              <a href="#" class="EPs-title">EP205</a>
            </div>

            <div class="single-latest-EPs">
              <p class="EPs-date">December 8, 2018</p>
              <a href="#" class="EPs-title">EP204</a>
            </div>
          </div>
        </div>


        <div class="col-12 col-sm-6 col-lg-3">
          <div class="single-footer-widget mb-80">

            <h4 class="widget-title">Follow Us</h4>

            <div class="footer-social-info">
              <a href="#" class="facebook" data-toggle="tooltip" data-placement="top" title="Facebook"><i class="fa fa-facebook"></i></a>
              <a href="#" class="twitter" data-toggle="tooltip" data-placement="top" title="Twitter"><i class="fa fa-twitter"></i></a>
              <a href="#" class="pinterest" data-toggle="tooltip" data-placement="top" title="Pinterest"><i class="fa fa-pinterest"></i></a>
              <a href="#" class="instagram" data-toggle="tooltip" data-placement="top" title="Instagram"><i class="fa fa-instagram"></i></a>
              <a href="#" class="youtube" data-toggle="tooltip" data-placement="top" title="YouTube"><i class="fa fa-youtube-play"></i></a>
            </div>

            <div class="app-download-button mt-30">
              <a href="#"><img src="./img/core-img/app-store.png" alt=""></a>
              <a href="#"><img src="./img/core-img/google-play.png" alt=""></a>
            </div>
          </div>
        </div>

      </div>
    </div>
  </footer>


  <script src="js/jquery.min.js"></script>

  <script src="js/popper.min.js"></script>

  <script src="js/bootstrap.min.js"></script>

  <script src="js/soundemic.bundle.js"></script>

  <script src="js/default-assets/active.js"></script>

</body>

</html>