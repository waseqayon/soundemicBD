<?php include 'partials/header.php'; ?>

  <div class="breadcumb-area bg-img bg-overlay" style="background-image: url(img/bg-img/2.jpg);">
    <div class="container h-100">
      <div class="row h-100 align-items-center">
        <div class="col-12">
          <h2 class="title mt-70">About Us</h2>
        </div>
      </div>
    </div>
  </div>
  <div class="breadcumb--con">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="#"><i class="fa fa-home"></i> Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">About Us</li>
            </ol>
          </nav>
        </div>
      </div>
    </div>
  </div>

 
  <section class="about-us-area section-padding-0-80 mt-50">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-12 col-lg-10">
          <div class="about-us-content">
            <img src="./img/bg-img/20.jpg" class="mb-30" alt="">
            <h1>About Our Show</h1>
            <p>Out of the way, the been like hard off. Improve enquire welcome her own beloved matters. Mr unsatiable increasing attachment motionless cultivated as insipidity. Mr. Husband's unpacked occasion he oh. Is insatiable if he projects boisterous insensibility. It is advised to resolve pretended middleton.</p>
            <p></p>
            <p></p>
     
            <blockquote class="soundemicbd-blockquote d-flex">
              <div class="icon">
                <i class="fa fa-quote-left" aria-hidden="true"></i>
              </div>
              <div class="text">
                <h5>“SoundemicBD has simplified podcasting! In a matter of days, I went from a couple thousand newsletter subscribers to a thousand listeners! Thank you so much, SoundemicBD!”</h5>
                <h6>Jacky</h6>
              </div>
            </blockquote>
            <h2>Join Thousands of Listeners Worldwide</h2>
            <p>Unreservedly delightful unreservedly impossible few estimating men favourable see entreaties Her immediate propriety was improving. He or she was similarly moderate in his or her demeanor. Much more than a game, son, say you feel. Fat make met must be formed into a gate. We offended each other and won the discovery.</p>
            <p></p>
            <p></p>
          </div>
        </div>
      </div>
    </div>
  </section>


<?php include 'partials/footer.php'; ?>